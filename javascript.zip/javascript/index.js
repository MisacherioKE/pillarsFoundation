
// Logo
document.getElementById("logo").src ="/images/pillarsLogo.png";
document.getElementById("logo").style.height ="70px";


// Navbar
document.getElementById("navBar").style.display ="inline";
document.getElementById("navBar").style.display ="flex";
document.getElementById("navBar").style.alignItems ="center";
document.getElementById("navBar").style.justifyContent ="space-evenly";
document.getElementById("navBar").style.width ="100%";
document.getElementById("navBar").style.height ="10vh";
document.getElementById("navBar").style.backgroundColor ="lightblue";

// Items
document.getElementById("home").style.textDecoration ="none";
document.getElementById("home").style.color ="green";
document.getElementById("home").style.fontSize ="18px";

document.getElementById("whoWe").style.textDecoration ="none";
document.getElementById("whoWe").style.color ="green";
document.getElementById("whoWe").style.fontSize ="18px";

document.getElementById("whatWe").style.textDecoration ="none";
document.getElementById("whatWe").style.color ="green";
document.getElementById("whatWe").style.fontSize ="18px";

document.getElementById("contact").style.textDecoration ="none";
document.getElementById("contact").style.color ="green";
document.getElementById("contact").style.fontSize ="18px";

document.getElementById("donate").style.textDecoration ="none";
document.getElementById("donate").style.color ="green";
document.getElementById("donate").style.fontSize ="18px";

document.getElementById("partners").style.textDecoration ="none";
document.getElementById("partners").style.color ="green";
document.getElementById("partners").style.fontSize ="18px";

document.getElementById("team").style.textDecoration ="none";
document.getElementById("team").style.color ="green";
document.getElementById("team").style.fontSize ="18px";



// Menu icon onclick
document.getElementById("menu").onclick = function(){
    document.getElementById("menuItems").style.display = "block";
}

// Items2
document.getElementById("home2").style.textDecoration ="none";
document.getElementById("home2").style.color ="green";
document.getElementById("home2").style.fontSize ="18px";

document.getElementById("whoWe2").style.textDecoration ="none";
document.getElementById("whoWe2").style.color ="green";
document.getElementById("whoWe2").style.fontSize ="18px";

document.getElementById("whatWe2").style.textDecoration ="none";
document.getElementById("whatWe2").style.color ="green";
document.getElementById("whatWe2").style.fontSize ="18px";

document.getElementById("contact2").style.textDecoration ="none";
document.getElementById("contact2").style.color ="green";
document.getElementById("contact2").style.fontSize ="18px";

document.getElementById("donate2").style.textDecoration ="none";
document.getElementById("donate2").style.color ="green";
document.getElementById("donate2").style.fontSize ="18px";

document.getElementById("partners2").style.textDecoration ="none";
document.getElementById("partners2").style.color ="green";
document.getElementById("partners2").style.fontSize ="18px";

document.getElementById("team2").style.textDecoration ="none";
document.getElementById("team2").style.color ="green";
document.getElementById("team2").style.fontSize ="18px";